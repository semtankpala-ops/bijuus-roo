import test from 'node:test';
import assert from 'node:assert/strict';

const validRoles=['MEMBRO','LIDER','ADMIN'];
test('V27: papéis válidos',()=>{
  assert.equal(validRoles.includes('MEMBRO'),true);
  assert.equal(validRoles.includes('ADMIN'),true);
});

test('V27: senha mínima',()=>{
  assert.equal('1234567'.length>=8,false);
  assert.equal('12345678'.length>=8,true);
});

test('V27: vencedor PvP precisa pertencer à partida',()=>{
  const teams=['a','b'];
  assert.equal(teams.includes('c'),false);
  assert.equal(teams.includes('a'),true);
});

test('V27: origem desconhecida é rejeitada em mutações',()=>{
  const host='guild.example.com';
  const origin=new URL('https://evil.example.com').host;
  assert.notEqual(origin,host);
});

console.log('Smoke tests V27 OK');
