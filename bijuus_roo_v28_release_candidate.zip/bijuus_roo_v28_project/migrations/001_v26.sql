-- Bijuus Roo V26 production hardening
-- Idempotent cleanup and indexes for password reset/session maintenance.
CREATE INDEX IF NOT EXISTS idx_recuperacao_ativa ON recuperacao_senha(usuario_id, expira_em) WHERE usado_em IS NULL;
CREATE INDEX IF NOT EXISTS idx_pvp_partida_evento_round ON pvp_partidas(evento_id, rodada, numero);
CREATE INDEX IF NOT EXISTS idx_pvp_desempenho_partida ON pvp_desempenho(partida_id);
