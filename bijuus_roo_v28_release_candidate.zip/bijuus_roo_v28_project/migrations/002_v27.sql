-- V27: índices/guardrails para produção.
CREATE INDEX IF NOT EXISTS idx_usuarios_status ON usuarios(status_conta);
CREATE INDEX IF NOT EXISTS idx_pvp_eventos_status ON pvp_eventos(status);
CREATE INDEX IF NOT EXISTS idx_auditoria_usuario_data ON auditoria(usuario_id, criado_em DESC);
CREATE INDEX IF NOT EXISTS idx_recuperacao_expira ON recuperacao_senha(expira_em);
